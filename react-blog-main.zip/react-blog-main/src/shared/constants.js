export const POSTS_URL = 'https://5fb3db44b6601200168f7fba.mockapi.io/api/posts/';

export const POSTS = [
  {
    id: 1,
    title: "Post 1",
    description:
      "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Sapiente, fugiat harum. Voluptatibus beatae corrupti nulla, qui odit mollitia doloremque rerum magni rem aut laborum, maiores officiis laboriosam hic. Ratione, voluptas?",
    liked: false,
  },
  {
    id: 2,
    title: "Post 2",
    description:
      "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Sapiente, fugiat harum. Voluptatibus beatae corrupti nulla, qui odit mollitia doloremque rerum magni rem aut laborum, maiores officiis laboriosam hic. Ratione, voluptas?",
    liked: false,
  },
  {
    id: 3,
    title: "Post 3",
    description:
      "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Sapiente, fugiat harum. Voluptatibus beatae corrupti nulla, qui odit mollitia doloremque rerum magni rem aut laborum, maiores officiis laboriosam hic. Ratione, voluptas?",
    liked: false,
  },
];
